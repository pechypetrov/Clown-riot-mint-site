
import React from 'react';
import Mint from './Mint';

function App() {
  return (
    <div className="App">
      <Mint />
    </div>
  );
}

export default App;
